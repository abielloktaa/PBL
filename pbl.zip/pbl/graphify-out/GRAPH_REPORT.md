# Graph Report - pbl  (2026-11-22)

## Corpus Check
- 45 files · ~92,743 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 9 file(s) not represented in the graph (top: (none) 8, .phpb 1)

## Summary
- 151 nodes · 170 edges · 45 communities (7 shown, 38 thin omitted)
- Extraction: 99% EXTRACTED · 1% INFERRED · 0% AMBIGUOUS · INFERRED: 2 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `67f0058b`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- .agents/skills/antislop-human/contrast-check.py
- .agents/skills/antislop-human/contrast-mcp.py
- .claude/skills/antislop-human/contrast-check.py
- .claude/skills/antislop-human/contrast-mcp.py
- keranjang.php
- user/dashboard.php
- katalog.php
- navbar.php
- user/pesanan.php

## God Nodes (most connected - your core abstractions)
1. `selftest()` - 6 edges
2. `main()` - 6 edges
3. `selftest()` - 6 edges
4. `main()` - 6 edges
5. `parse_pairing()` - 5 edges
6. `parse_pairing()` - 5 edges
7. `contrast_ratio()` - 4 edges
8. `main()` - 4 edges
9. `parse_hex()` - 4 edges
10. `contrast_ratio()` - 4 edges

## Surprising Connections (you probably didn't know these)
- `parse_hex()` --calls--> `re`  [EXTRACTED]
  .agents/skills/antislop-human/contrast-check.py →   _Bridges community 0 → community 2_
- `relative_luminance()` --calls--> `re`  [EXTRACTED]
  .agents/skills/antislop-human/contrast-mcp.py →   _Bridges community 1 → community 2_
- `main()` --calls--> `json`  [EXTRACTED]
  .claude/skills/antislop-human/contrast-mcp.py →   _Bridges community 3 → community 1_
- `relative_luminance()` --calls--> `re`  [EXTRACTED]
  .claude/skills/antislop-human/contrast-mcp.py →   _Bridges community 3 → community 2_

## Import Cycles
- None detected.

## Communities (45 total, 38 thin omitted)

### Community 0 - ".agents/skills/antislop-human/contrast-check.py"
Cohesion: 0.23
Nodes (9): contrast_ratio(), linearize(), luminance(), main(), parse_hex(), parse_pairing(), parse_reference_rows(), reference_doc_path() (+1 more)

### Community 1 - ".agents/skills/antislop-human/contrast-mcp.py"
Cohesion: 0.28
Nodes (9): _channel(), check_contrast(), contrast_ratio(), _error(), main(), relative_luminance(), _reply(), _send() (+1 more)

### Community 2 - ".claude/skills/antislop-human/contrast-check.py"
Cohesion: 0.27
Nodes (9): contrast_ratio(), linearize(), luminance(), main(), parse_hex(), parse_pairing(), parse_reference_rows(), reference_doc_path() (+1 more)

### Community 3 - ".claude/skills/antislop-human/contrast-mcp.py"
Cohesion: 0.29
Nodes (9): _channel(), check_contrast(), contrast_ratio(), _error(), main(), relative_luminance(), _reply(), _send() (+1 more)

### Community 4 - "keranjang.php"
Cohesion: 0.39
Nodes (6): cekKeranjangKosong(), closeDeleteModal(), confirmDelete(), hitungTotal(), tampilNotifStok(), updateQty()

### Community 6 - "katalog.php"
Cohesion: 0.24
Nodes (4): db_all(), e(), tombol_halaman(), url_katalog()

### Community 7 - "navbar.php"
Cohesion: 0.33
Nodes (3): desktopMenu, navbarContainer, userText

## Knowledge Gaps
- **38 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `parse_pairing()` connect `.agents/skills/antislop-human/contrast-check.py` to `.claude/skills/antislop-human/contrast-check.py`?**
  _High betweenness centrality (0.006) - this node is a cross-community bridge._