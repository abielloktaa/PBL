<?php
session_start();
include __DIR__ . '/../koneksi.php';

$ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';

function balas_json(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

// Hanya user yang sudah login
if (!isset($_SESSION['username']) || $_SESSION['id_role'] != '1') {
    if ($ajax) {
        balas_json(['ok' => false, 'pesan' => 'Sesi berakhir. Silakan masuk kembali.'], 401);
    }
    header('Location:../login.php?pesan=belum_login');
    exit;
}

if (!isset($_SESSION['keranjang']) || !is_array($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
}

// Hapus satu item dari keranjang
if (isset($_POST['hapus'])) {
    $id_hapus = (int) $_POST['hapus'];
    unset($_SESSION['keranjang'][$id_hapus]);

    $total_qty    = (int) array_sum($_SESSION['keranjang']);
    $total_harga  = 0;
    foreach ($_SESSION['keranjang'] as $id => $qty) {
        $st = $koneksi->prepare('SELECT price FROM product WHERE id_product = ?');
        $st->bind_param('i', $id);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        $st->close();
        if ($row) $total_harga += (int) $row['price'] * (int) $qty;
    }

    balas_json([
        'ok'           => true,
        'total_qty'    => $total_qty,
        'total_harga'  => $total_harga,
    ]);
}

// Update jumlah item (plus / minus / ketik manual)
if (isset($_POST['update_qty'])) {
    $id_produk   = (int) ($_POST['id_produk'] ?? 0);
    $jumlah_baru = max(0, (int) ($_POST['jumlah'] ?? 0));

    // Validasi stok aktual dari database
    $st = $koneksi->prepare('SELECT name_product, stock, price FROM product WHERE id_product = ?');
    $st->bind_param('i', $id_produk);
    $st->execute();
    $prod = $st->get_result()->fetch_assoc();
    $st->close();

    if (!$prod) {
        balas_json(['ok' => false, 'pesan' => 'Produk tidak ditemukan.'], 404);
    }

    $stok = (int) $prod['stock'];
    if ($jumlah_baru > $stok) {
        $jumlah_baru = $stok;
    }

    if ($jumlah_baru <= 0) {
        unset($_SESSION['keranjang'][$id_produk]);
    } else {
        $_SESSION['keranjang'][$id_produk] = $jumlah_baru;
    }

    $subtotal     = (int) $prod['price'] * $jumlah_baru;
    $total_qty    = (int) array_sum($_SESSION['keranjang']);
    $total_harga  = 0;
    foreach ($_SESSION['keranjang'] as $id => $qty) {
        $s = $koneksi->prepare('SELECT price FROM product WHERE id_product = ?');
        $s->bind_param('i', $id);
        $s->execute();
        $r = $s->get_result()->fetch_assoc();
        $s->close();
        if ($r) $total_harga += (int) $r['price'] * (int) $qty;
    }

    balas_json([
        'ok'          => true,
        'dihapus'     => $jumlah_baru <= 0,
        'dibatasi'    => (int) ($_POST['jumlah'] ?? 0) > $stok,
        'jumlah'      => $jumlah_baru,
        'stok'        => $stok,
        'subtotal'    => $subtotal,
        'total_qty'   => $total_qty,
        'total_harga' => $total_harga,
    ]);
}

// Tambah ke keranjang
if (isset($_POST['tambah_keranjang'])) {
    $id_produk = (int) ($_POST['id_produk'] ?? 0);
    $qty       = max(1, (int) ($_POST['qty'] ?? 1));

    $st = $koneksi->prepare('SELECT name_product, stock FROM product WHERE id_product = ?');
    $st->bind_param('i', $id_produk);
    $st->execute();
    $prod = $st->get_result()->fetch_assoc();
    $st->close();

    $error = null;
    if (!$prod) {
        $error = 'Produk tidak ditemukan.';
    } elseif ((int) $prod['stock'] <= 0) {
        $error = $prod['name_product'] . ' sedang habis.';
    }

    if ($error !== null) {
        if ($ajax) {
            balas_json(['ok' => false, 'pesan' => $error], 422);
        }
        header('Location:' . ($_SERVER['HTTP_REFERER'] ?? '../user/katalog.php'));
        exit;
    }

    $stok    = (int) $prod['stock'];
    $sudah   = (int) ($_SESSION['keranjang'][$id_produk] ?? 0);
    $diminta = $sudah + $qty;
    $_SESSION['keranjang'][$id_produk] = min($diminta, $stok);

    if ($ajax) {
        balas_json([
            'ok'       => true,
            'nama'     => $prod['name_product'],
            'jumlah'   => (int) array_sum($_SESSION['keranjang']),
            'dibatasi' => $diminta > $stok,
            'stok'     => $stok,
        ]);
    }

    // Form biasa (tanpa JavaScript): kembali ke keranjang
    header('Location:../user/keranjang.php');
    exit;
}

if ($ajax) {
    balas_json(['ok' => false, 'pesan' => 'Permintaan tidak valid.'], 400);
}
header('Location:../user/katalog.php');
exit;
