<?php
session_start();
include __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['username']) || $_SESSION['id_role'] != '1') {
    header('location:../index.php?pesan=belum_login');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang belanja - GalonKu</title>
    <?php include '../layout/assets.php'; ?>
    <style>
        /* Transisi backdrop modal hapus */
        #deleteModal {
            transition: opacity 200ms ease-out;
        }
        #deleteModal.modal-masuk   { opacity: 1; pointer-events: auto; }
        #deleteModal.modal-keluar  { opacity: 0; pointer-events: none; }

        /* Transisi kartu dialog modal hapus */
        #deleteCard {
            transition: opacity 200ms ease-out, transform 200ms ease-out;
        }
        #deleteCard.card-masuk  { opacity: 1;  transform: scale(1)    translateY(0); }
        #deleteCard.card-keluar { opacity: 0;  transform: scale(0.95) translateY(8px); }

        @media (prefers-reduced-motion: reduce) {
            #deleteModal, #deleteCard { transition: none; }
        }

        /* Notifikasi stok inline */
        #stokNotif {
            transition: opacity 150ms ease-out, max-height 150ms ease-out;
            overflow: hidden;
            max-height: 0;
            opacity: 0;
        }
        #stokNotif.notif-tampil {
            max-height: 48px;
            opacity: 1;
        }
    </style>
</head>
<body class="font-sans antialiased bg-surface">

    <?php include '../layout/navbar.php'; ?>

    <main class="max-w-4xl mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-extrabold text-primary">Keranjang belanja</h1>
            <a href="katalog.php" class="text-sm font-semibold text-secondary hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary rounded">
                <i class="fa-solid fa-plus mr-1" aria-hidden="true"></i> Tambah barang
            </a>
        </div>

        <?php if (empty($_SESSION['keranjang'])) : ?>
            <div id="tampilan-kosong" class="bg-white p-8 rounded-2xl shadow-soft text-center border border-gray-200">
                <i class="fa-solid fa-cart-shopping text-6xl text-gray-300 mb-4" aria-hidden="true"></i>
                <p class="text-gray-500 mb-4">Belum ada barang di sini.</p>
                <a href="katalog.php" class="inline-block bg-primary text-white px-6 py-2.5 rounded-xl hover:bg-secondary focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">Mulai belanja</a>
            </div>
        <?php else : ?>

            <div id="tampilan-keranjang" class="bg-white rounded-2xl shadow-soft border border-gray-200 overflow-hidden">
                <div class="p-4 sm:p-6 overflow-x-auto">
                    <table class="w-full text-left min-w-[480px]">
                        <thead>
                            <tr class="border-b text-sm text-gray-500">
                                <th class="pb-3 font-semibold">Produk</th>
                                <th class="pb-3 text-center w-36 font-semibold">Jumlah</th>
                                <th class="pb-3 text-right font-semibold">Subtotal</th>
                                <th class="pb-3 text-center w-14 font-semibold">
                                    <span class="sr-only">Aksi</span>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total_belanja = 0;
                            foreach ($_SESSION['keranjang'] as $id_produk => $qty) {
                                $query = mysqli_query($koneksi, "SELECT * FROM product WHERE id_product = '$id_produk'");
                                $p = mysqli_fetch_assoc($query);

                                if (!$p) continue;

                                $subtotal = $p['price'] * $qty;
                                $total_belanja += $subtotal;
                            ?>
                            <tr class="border-b border-gray-100" id="row-<?= $id_produk; ?>">
                                <td class="py-4 pr-4">
                                    <p class="font-semibold text-primary"><?= htmlspecialchars($p['name_product']); ?></p>
                                    <p class="text-xs text-gray-400 mt-0.5">Rp <?= number_format($p['price'], 0, ',', '.'); ?> / item</p>
                                </td>

                                <td class="py-4 text-center">
                                    <div class="flex items-center justify-center gap-1.5">
                                        <button type="button"
                                                onclick="updateQty(<?= $id_produk; ?>, -1, <?= $p['stock']; ?>)"
                                                aria-label="Kurangi jumlah <?= htmlspecialchars($p['name_product']); ?>"
                                                class="w-9 h-9 min-w-[36px] min-h-[36px] rounded-lg bg-gray-100 text-primary hover:bg-gray-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition flex items-center justify-center">
                                            <i class="fa-solid fa-minus text-xs" aria-hidden="true"></i>
                                        </button>

                                        <input type="number" id="qty-<?= $id_produk; ?>" value="<?= $qty; ?>"
                                               onchange="updateQty(<?= $id_produk; ?>, 0, <?= $p['stock']; ?>)"
                                               aria-label="Jumlah <?= htmlspecialchars($p['name_product']); ?>"
                                               min="0" max="<?= $p['stock']; ?>"
                                               class="w-12 text-center py-1.5 border border-gray-300 rounded-lg text-sm font-bold text-primary focus:ring-2 focus:ring-secondary outline-none">

                                        <button type="button"
                                                onclick="updateQty(<?= $id_produk; ?>, 1, <?= $p['stock']; ?>)"
                                                aria-label="Tambah jumlah <?= htmlspecialchars($p['name_product']); ?>"
                                                class="w-9 h-9 min-w-[36px] min-h-[36px] rounded-lg bg-gray-100 text-primary hover:bg-gray-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition flex items-center justify-center">
                                            <i class="fa-solid fa-plus text-xs" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </td>

                                <td class="py-4 text-right font-bold text-primary" id="subtotal-<?= $id_produk; ?>" data-price="<?= $p['price']; ?>">
                                    Rp <?= number_format($subtotal, 0, ',', '.'); ?>
                                </td>

                                <td class="py-4 text-center">
                                    <button type="button"
                                            onclick="hapusBarang(<?= $id_produk; ?>)"
                                            aria-label="Hapus <?= htmlspecialchars($p['name_product']); ?> dari keranjang"
                                            class="w-10 h-10 min-w-[40px] min-h-[40px] rounded-xl text-red-400 hover:text-red-600 hover:bg-red-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-400 transition flex items-center justify-center mx-auto">
                                        <i class="fa-solid fa-trash-can text-sm" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

                <!-- Notifikasi stok inline (menggantikan alert() native) -->
                <div id="stokNotif" class="px-4 sm:px-6" role="status" aria-live="polite">
                    <p id="stokNotifPesan" class="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-3"></p>
                </div>

                <div class="bg-gray-50 p-4 sm:p-6 flex flex-col md:flex-row justify-between items-center border-t border-gray-200 gap-4">
                    <div class="w-full md:w-auto text-center md:text-left">
                        <p class="text-sm text-gray-500">Total pembayaran</p>
                        <p class="text-2xl font-extrabold text-primary" id="total-belanja-tampil">
                            Rp <?= number_format($total_belanja, 0, ',', '.'); ?>
                        </p>
                    </div>

                    <div class="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                        <button type="button" onclick="checkout()"
                                class="bg-primary text-white px-8 py-3 rounded-xl font-bold hover:bg-secondary focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition w-full sm:w-auto">
                            Lanjut ke checkout
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <!-- Modal konfirmasi hapus -->
    <div id="deleteModal" role="dialog" aria-modal="true" aria-labelledby="deleteModalTitle"
         class="modal-keluar fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4"
         style="pointer-events:none;">
        <div id="deleteCard" class="card-keluar bg-white rounded-2xl p-6 max-w-sm w-full text-center shadow-xl">
            <div class="w-16 h-16 mx-auto bg-red-50 rounded-full flex items-center justify-center mb-4">
                <i class="fa-solid fa-trash-can text-3xl text-red-500" aria-hidden="true"></i>
            </div>

            <h2 id="deleteModalTitle" class="text-xl font-extrabold text-primary mb-2">Hapus produk?</h2>
            <p class="text-sm text-gray-500 mb-6">Produk ini akan dihapus dari daftar belanjaan.</p>

            <div class="flex gap-3">
                <button id="deleteBatal" type="button"
                        class="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition">Batal</button>
                <button id="deleteKonfirm" type="button"
                        class="flex-1 bg-red-500 text-white py-3 rounded-xl font-semibold hover:bg-red-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-red-500 transition">Ya, hapus</button>
            </div>
        </div>
    </div>

    <script>
        var productToDelete  = null;
        var hapusPemicu      = null;
        var deleteModal      = document.getElementById('deleteModal');
        var deleteCard       = document.getElementById('deleteCard');
        var stokNotif        = document.getElementById('stokNotif');
        var stokNotifPesan   = document.getElementById('stokNotifPesan');
        var stokNotifTimer   = null;

        // Buka modal hapus dengan animasi
        function hapusBarang(idProduk) {
            productToDelete = idProduk;
            hapusPemicu = document.activeElement;

            deleteModal.style.pointerEvents = 'auto';
            deleteModal.classList.remove('modal-keluar');
            deleteCard.classList.remove('card-keluar');
            requestAnimationFrame(function () {
                requestAnimationFrame(function () {
                    deleteModal.classList.add('modal-masuk');
                    deleteCard.classList.add('card-masuk');
                    document.getElementById('deleteBatal').focus();
                });
            });
        }

        // Tutup modal hapus dengan animasi
        function closeDeleteModal() {
            deleteModal.classList.remove('modal-masuk');
            deleteCard.classList.remove('card-masuk');
            deleteModal.classList.add('modal-keluar');
            deleteCard.classList.add('card-keluar');
            deleteModal.style.pointerEvents = 'none';
            productToDelete = null;
            if (hapusPemicu) hapusPemicu.focus();
        }

        // Konfirmasi hapus – AJAX ke action/actionkeranjang.php
        function confirmDelete() {
            if (!productToDelete) return;

            var id = productToDelete;
            var formData = new FormData();
            formData.append('hapus', id);

            fetch('../action/actionkeranjang.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) return;
                var row = document.getElementById('row-' + id);
                if (row) row.remove();
                hitungTotal();
                cekKeranjangKosong();
                closeDeleteModal();
            })
            .catch(function () {
                closeDeleteModal();
            });
        }

        // Update qty – AJAX ke action/actionkeranjang.php
        function updateQty(idProduk, change, maxStock) {
            var input   = document.getElementById('qty-' + idProduk);
            var current = parseInt(input.value) || 0;
            var newVal  = change !== 0 ? current + change : (parseInt(input.value) || 0);

            // Tampilkan notifikasi stok inline alih-alih alert()
            if (newVal > maxStock) {
                tampilNotifStok('Jumlah disesuaikan dengan stok yang tersedia (' + maxStock + ').');
                newVal = maxStock;
            } else if (newVal < 0) {
                newVal = 0;
            }

            input.value = newVal;

            var formData = new FormData();
            formData.append('update_qty', '1');
            formData.append('id_produk', idProduk);
            formData.append('jumlah', newVal);

            fetch('../action/actionkeranjang.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) return;
                if (d.dihapus) {
                    var row = document.getElementById('row-' + idProduk);
                    if (row) row.remove();
                    cekKeranjangKosong();
                } else {
                    var elSub = document.getElementById('subtotal-' + idProduk);
                    if (elSub) elSub.innerText = 'Rp ' + d.subtotal.toLocaleString('id-ID');
                    if (d.dibatasi) tampilNotifStok('Jumlah disesuaikan dengan stok yang tersedia (' + d.stok + ').');
                }
                hitungTotal();
            });
        }

        function tampilNotifStok(pesan) {
            if (stokNotifTimer) clearTimeout(stokNotifTimer);
            stokNotifPesan.textContent = pesan;
            stokNotif.classList.add('notif-tampil');
            stokNotifTimer = setTimeout(function () {
                stokNotif.classList.remove('notif-tampil');
            }, 3500);
        }

        function hitungTotal() {
            var total = 0;
            document.querySelectorAll('[id^="subtotal-"]').forEach(function (el) {
                var id    = el.id.replace('subtotal-', '');
                var price = parseInt(el.getAttribute('data-price')) || 0;
                var qty   = parseInt((document.getElementById('qty-' + id) || {}).value) || 0;
                total += price * qty;
            });
            var el = document.getElementById('total-belanja-tampil');
            if (el) el.innerText = 'Rp ' + total.toLocaleString('id-ID');
        }

        function cekKeranjangKosong() {
            if (document.querySelectorAll('tbody tr').length === 0) {
                window.location.reload();
            }
        }

        function checkout() {
            window.location.href = 'checkout.php';
        }

        // Event listeners modal hapus
        document.getElementById('deleteBatal').addEventListener('click', closeDeleteModal);
        document.getElementById('deleteKonfirm').addEventListener('click', confirmDelete);
        deleteModal.addEventListener('click', function (ev) {
            if (ev.target === deleteModal) closeDeleteModal();
        });
        document.addEventListener('keydown', function (ev) {
            if (ev.key === 'Escape' && deleteModal.classList.contains('modal-masuk')) closeDeleteModal();
        });
    </script>

    <?php include '../layout/footer.php'; ?>
</body>
</html>
