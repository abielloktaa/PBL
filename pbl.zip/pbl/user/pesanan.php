<?php
session_start();
include __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['username']) || $_SESSION['id_role'] != "1") {
    header("location:../index.php?pesan=akses_ditolak");
    exit();
}

$username = $_SESSION['username'];
$id_user  = (int) $_SESSION['id_user'];

if (!function_exists('e')) {
    function e($s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
    }
}
if (!function_exists('rupiah')) {
    function rupiah($n): string
    {
        return 'Rp ' . number_format((float) $n, 0, ',', '.');
    }
}
if (!function_exists('db_all')) {
    function db_all(mysqli $k, string $sql, string $types = '', array $params = []): array
    {
        $st = $k->prepare($sql);
        if ($types !== '') {
            $st->bind_param($types, ...$params);
        }
        $st->execute();
        $res  = $st->get_result();
        $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        $st->close();
        return $rows;
    }
}
if (!function_exists('punya_foto')) {
    function punya_foto($img): bool
    {
        return !empty($img) && is_string($img) && strpos($img, 'dummy') === false;
    }
}

// 08xx -> 62xx untuk wa.me; null jika nomor kosong.
function wa_link(?string $hp, string $teks): ?string
{
    $d = preg_replace('/\D+/', '', (string) $hp);
    if ($d === '') {
        return null;
    }
    if ($d[0] === '0') {
        $d = '62' . substr($d, 1);
    }
    return 'https://wa.me/' . $d . '?text=' . rawurlencode($teks);
}

$tahap_dari = ['MENUNGGU KONFIRMASI AGENT' => 0, 'DIPROSES' => 1, 'PENGANTARAN' => 2, 'SELESAI' => 3];
$langkah    = ['Menunggu', 'Diproses', 'Diantar', 'Selesai'];
$status_cfg = [
    0 => ['judul' => 'Menunggu konfirmasi depot', 'info' => 'Depot belum menerima pesananmu.',           'ikon' => 'fa-hourglass-half'],
    1 => ['judul' => 'Sedang diproses',           'info' => 'Depot sedang menyiapkan pesananmu.',      'ikon' => 'fa-box-open'],
    2 => ['judul' => 'Sedang diantar',            'info' => 'Pesananmu dalam perjalanan ke alamatmu.', 'ikon' => 'fa-truck-fast'],
];

// Warna kartu ada di satu tempat. Oranye hanya dipakai di atas biru tua: di atas putih kontrasnya kurang.
$tema = [
    'prioritas' => [
        'kartu' => 'bg-primary text-white shadow-pop',
        'redup' => 'text-white/70',
        'label' => 'text-brandOrange',
        'track' => 'bg-white/15',
        'isi'   => 'bg-brandOrange',
        'tanda' => 'bg-brandOrange text-primary',
        'thumb' => 'bg-white/10 text-brandOrange',
        'garis' => 'divide-white/10 border-white/15',
        'utama' => 'bg-white text-primary hover:bg-support focus-visible:ring-white',
        'biasa' => 'border border-white/30 text-white hover:bg-white/10 focus-visible:ring-white',
    ],
    'biasa' => [
        'kartu' => 'bg-white text-primary border border-gray-200',
        'redup' => 'text-gray-600',
        'label' => 'text-secondary',
        'track' => 'bg-gray-200',
        'isi'   => 'bg-secondary',
        'tanda' => 'bg-secondary text-white',
        'thumb' => 'bg-blue-50 text-secondary',
        'garis' => 'divide-gray-100 border-gray-100',
        'utama' => 'bg-primary text-white hover:bg-secondary focus-visible:ring-secondary',
        'biasa' => 'border border-gray-300 text-gray-700 hover:bg-gray-100 focus-visible:ring-secondary',
    ],
];

$limit = 8;
$page  = max(1, (int) ($_GET['page'] ?? 1));

function url_pesanan(int $p): string
{
    return 'pesanan.php' . ($p > 1 ? '?page=' . $p : '') . '#riwayat';
}

// tahap = tahap paling awal di antara item pesanan (0-2 berjalan, 3 selesai), sama seperti logika lama.
$sql_dasar = "SELECT o.id_order, o.order_date, o.total_price, u.depot, u.username AS agent_name, u.no_hp AS agent_hp,
                     COALESCE((SELECT MIN(CASE od.status
                                   WHEN 'MENUNGGU KONFIRMASI AGENT' THEN 0 WHEN 'DIPROSES' THEN 1
                                   WHEN 'PENGANTARAN' THEN 2 WHEN 'SELESAI' THEN 3 ELSE 0 END)
                               FROM order_detail od WHERE od.id_order = o.id_order), 0) AS tahap
              FROM orders o
              LEFT JOIN users u ON o.id_agent = u.id_user
              WHERE o.id_user = ?";

$n_aktif   = 0;
$n_selesai = 0;
foreach (db_all($koneksi, "SELECT tahap, COUNT(*) AS n FROM ($sql_dasar) t GROUP BY tahap", 'i', [$id_user]) as $r) {
    if ((int) $r['tahap'] === 3) {
        $n_selesai += (int) $r['n'];
    } else {
        $n_aktif += (int) $r['n'];
    }
}

$total_pages = max(1, (int) ceil($n_selesai / $limit));
$page        = min($page, $total_pages);
$offset      = ($page - 1) * $limit;

$aktif = db_all($koneksi, "SELECT * FROM ($sql_dasar) t WHERE tahap < 3 ORDER BY tahap DESC, order_date DESC", 'i', [$id_user]);
$selesai = db_all(
    $koneksi,
    "SELECT * FROM ($sql_dasar) t WHERE tahap = 3 ORDER BY order_date DESC LIMIT ? OFFSET ?",
    'iii',
    [$id_user, $limit, $offset]
);

$item_per_order = [];
$semua = array_merge($aktif, $selesai);
if ($semua) {
    $ids  = array_map('intval', array_column($semua, 'id_order'));
    $in   = implode(',', array_fill(0, count($ids), '?'));
    $rows = db_all(
        $koneksi,
        "SELECT od.id_order, od.quantity_item, od.subtotal, od.status, p.name_product, p.img
         FROM order_detail od JOIN product p ON od.id_product = p.id_product
         WHERE od.id_order IN ($in) ORDER BY od.id_order, od.id_product",
        str_repeat('i', count($ids)),
        $ids
    );
    foreach ($rows as $r) {
        $item_per_order[$r['id_order']][] = $r;
    }
}

function nama_depot(array $o): string
{
    return trim((string) ($o['depot'] ?? '')) !== '' ? $o['depot'] : ($o['agent_name'] ?? 'Depot');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan - GalonKu</title>
    <?php include '../layout/assets.php'; ?>
    <style>
        /* Di layar kecil tiap baris tabel menjadi blok bertumpuk. */
        @media (max-width: 767px) {
            .tbl thead { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); }
            .tbl tbody tr { display: block; padding: .75rem 1rem; border-top: 1px solid #f3f4f6; }
            .tbl tbody tr:first-child { border-top: 0; }
            .tbl td { display: flex; justify-content: space-between; gap: 1rem; padding: .25rem 0 !important; text-align: right !important; }
            .tbl td::before { content: attr(data-label); color: #4b5563; font-size: .75rem; text-align: left; flex-shrink: 0; }
            .tbl td.aksi { justify-content: flex-end; gap: .5rem; padding-top: .5rem !important; }
            .tbl td.aksi::before { display: none; }
        }
    </style>
</head>
<body class="font-sans antialiased bg-surface flex flex-col min-h-screen">

    <?php include '../layout/navbar.php'; ?>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8 w-full flex-1">

        <header class="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
                <h1 class="text-2xl md:text-3xl font-extrabold text-primary mb-1">Pesanan saya</h1>
                <p class="text-sm text-gray-600">Yang masih berjalan ada di atas. Pesanan selesai tersimpan di riwayat.</p>
            </div>
            <dl class="flex gap-8">
                <div>
                    <dt class="text-xs font-semibold text-gray-600">Berjalan</dt>
                    <dd class="text-3xl font-extrabold text-primary tabular-nums leading-tight"><?= $n_aktif; ?></dd>
                </div>
                <div>
                    <dt class="text-xs font-semibold text-gray-600">Selesai</dt>
                    <dd class="text-3xl font-extrabold text-gray-600 tabular-nums leading-tight"><?= $n_selesai; ?></dd>
                </div>
            </dl>
        </header>

        <section aria-labelledby="h-aktif" class="mb-12">
            <h2 id="h-aktif" class="text-lg font-bold text-primary mb-4">Sedang berjalan</h2>

            <?php if (empty($aktif)): ?>
                <div class="bg-white rounded-2xl border border-gray-200 p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <p class="font-semibold text-primary">Tidak ada pesanan yang sedang berjalan</p>
                        <p class="text-sm text-gray-600 mt-1">Pesanan baru akan muncul di sini begitu kamu checkout.</p>
                    </div>
                    <a href="katalog.php" class="inline-flex items-center justify-center px-6 min-h-[44px] rounded-xl bg-primary text-white text-sm font-bold hover:bg-secondary active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">Belanja sekarang</a>
                </div>
            <?php else: ?>
                <div class="grid gap-4 lg:grid-cols-2">
                    <?php foreach ($aktif as $order):
                        $t      = (int) $order['tahap'];
                        $cfg    = $status_cfg[$t];
                        $tm     = $tema[$t === 2 ? 'prioritas' : 'biasa']; // hanya yang sedang diantar diangkat dengan warna dan bayangan
                        $items  = $item_per_order[$order['id_order']] ?? [];
                        $sisa   = count($items) - 2;
                        $wa     = wa_link($order['agent_hp'] ?? '', 'Halo, saya ingin menanyakan pesanan #ORD-' . $order['id_order']);
                        $persen = ($t + 1) * 25;
                        $dasar  = 'inline-flex items-center justify-center gap-2 min-h-[44px] px-5 rounded-xl text-sm font-bold active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent transition';
                    ?>
                        <article class="rounded-2xl p-5 md:p-6 flex flex-col <?= $tm['kartu']; ?> <?= count($aktif) === 1 ? 'lg:col-span-2' : ''; ?>">

                            <div class="flex items-center justify-between gap-3">
                                <span class="inline-flex items-center gap-2 text-sm font-bold <?= $tm['label']; ?>">
                                    <span class="w-2.5 h-2.5 rounded-full <?= $tm['isi']; ?>" aria-hidden="true"></span>
                                    Prioritas
                                </span>
                                <span class="font-mono text-xs <?= $tm['redup']; ?>">#ORD-<?= (int) $order['id_order']; ?></span>
                            </div>

                            <h3 class="mt-3 text-2xl md:text-3xl font-extrabold leading-tight"><?= e($cfg['judul']); ?></h3>
                            <p class="mt-1 text-sm <?= $tm['redup']; ?>"><?= e($cfg['info']); ?></p>

                            <div class="mt-6">
                                <div class="relative h-1.5 rounded-full <?= $tm['track']; ?>">
                                    <div class="absolute inset-y-0 left-0 rounded-full <?= $tm['isi']; ?>" style="width: <?= $persen; ?>%"></div>
                                    <span class="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full flex items-center justify-center text-xs <?= $tm['tanda']; ?>" style="left: <?= $persen; ?>%">
                                        <i class="fa-solid <?= $cfg['ikon']; ?>" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <ol class="mt-4 grid grid-cols-4 text-xs text-right" aria-label="Tahap pesanan">
                                    <?php foreach ($langkah as $i => $nama): ?>
                                        <li <?= $i === $t ? 'aria-current="step"' : ''; ?> class="<?= $i === $t ? 'font-bold' : ($i < $t ? 'font-semibold ' . $tm['redup'] : $tm['redup']); ?>"><?= e($nama); ?></li>
                                    <?php endforeach; ?>
                                </ol>
                            </div>

                            <ul class="mt-5 border-t divide-y <?= $tm['garis']; ?>">
                                <?php foreach (array_slice($items, 0, 2) as $it):
                                    $qty  = max(1, (int) $it['quantity_item']);
                                    $t_it = $tahap_dari[$it['status']] ?? 0;
                                ?>
                                    <li class="flex items-center gap-3 py-3">
                                        <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden <?= $tm['thumb']; ?>">
                                            <?php if (punya_foto($it['img'])): ?>
                                                <img src="../poto/<?= e($it['img']); ?>" alt="" class="w-full h-full object-cover" loading="lazy">
                                            <?php else: ?>
                                                <i class="fa-solid fa-droplet" aria-hidden="true"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex-1 min-w-0">
                                            <p class="font-semibold text-sm truncate"><?= e($it['name_product']); ?></p>
                                            <p class="text-xs <?= $tm['redup']; ?>">
                                                <?= $qty; ?> &times; <?= rupiah($it['subtotal'] / $qty); ?>
                                                <?php if ($t_it !== $t): ?> &middot; <span class="font-semibold"><?= e($langkah[$t_it]); ?></span><?php endif; ?>
                                            </p>
                                        </div>
                                        <p class="font-bold text-sm tabular-nums"><?= rupiah($it['subtotal']); ?></p>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <?php if ($sisa > 0): ?>
                                <p class="text-xs <?= $tm['redup']; ?> pb-1">+<?= $sisa; ?> produk lainnya, lihat di detail pesanan</p>
                            <?php endif; ?>

                            <div class="mt-auto pt-5 flex flex-wrap items-end justify-between gap-4">
                                <div>
                                    <p class="text-xs font-semibold <?= $tm['redup']; ?>">Total &middot; <?= e(nama_depot($order)); ?></p>
                                    <p class="text-2xl font-extrabold tabular-nums"><?= rupiah($order['total_price']); ?></p>
                                </div>
                                <div class="flex gap-2 w-full sm:w-auto">
                                    <?php if ($wa): ?>
                                        <a href="<?= e($wa); ?>" target="_blank" rel="noopener" class="flex-1 sm:flex-none <?= $dasar; ?> <?= $t === 2 ? $tm['utama'] : $tm['biasa']; ?>">
                                            <i class="fa-brands fa-whatsapp" aria-hidden="true"></i>Hubungi depot
                                        </a>
                                    <?php else: ?>
                                        <button type="button" disabled title="Nomor depot belum tersedia" class="flex-1 sm:flex-none <?= $dasar; ?> bg-gray-100 text-gray-600 cursor-not-allowed">
                                            <i class="fa-brands fa-whatsapp" aria-hidden="true"></i>Hubungi depot
                                        </button>
                                    <?php endif; ?>
                                    <a href="detail_pesanan.php?id=<?= (int) $order['id_order']; ?>" class="flex-1 sm:flex-none <?= $dasar; ?> <?= $t === 2 ? $tm['biasa'] : $tm['utama']; ?>">Detail</a>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section id="riwayat" aria-labelledby="h-riwayat" class="scroll-mt-28">
            <div class="flex items-baseline justify-between mb-4">
                <h2 id="h-riwayat" class="text-lg font-bold text-primary">Riwayat selesai</h2>
                <?php if ($n_selesai > 0): ?>
                    <p class="text-sm text-gray-600 tabular-nums"><?= $offset + 1; ?>&ndash;<?= $offset + count($selesai); ?> dari <?= $n_selesai; ?></p>
                <?php endif; ?>
            </div>

            <?php if (empty($selesai)): ?>
                <div class="bg-white rounded-2xl border border-gray-200 p-8 text-center">
                    <p class="font-semibold text-primary">Belum ada pesanan yang selesai</p>
                    <p class="text-sm text-gray-600 mt-1">Setelah pesananmu diterima, catatannya tersimpan di sini lengkap dengan invoice.</p>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                    <table class="tbl w-full text-sm">
                        <thead>
                            <tr class="bg-primary text-white text-xs font-semibold text-left">
                                <th scope="col" class="px-6 py-4">No. pesanan</th>
                                <th scope="col" class="px-6 py-4">Tanggal</th>
                                <th scope="col" class="px-6 py-4">Produk</th>
                                <th scope="col" class="px-6 py-4">Depot</th>
                                <th scope="col" class="px-6 py-4 text-right">Total</th>
                                <th scope="col" class="px-6 py-4"><span class="sr-only">Aksi</span></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php foreach ($selesai as $order):
                                $items = $item_per_order[$order['id_order']] ?? [];
                                $lain  = count($items) - 1;
                            ?>
                                <tr class="hover:bg-blue-50/60 transition-colors">
                                    <td data-label="No. pesanan" class="px-6 py-4 font-mono text-xs text-primary font-semibold whitespace-nowrap">#ORD-<?= (int) $order['id_order']; ?></td>
                                    <td data-label="Tanggal" class="px-6 py-4 text-gray-700 whitespace-nowrap tabular-nums"><?= e(date('d M Y', strtotime($order['order_date']))); ?></td>
                                    <td data-label="Produk" class="px-6 py-4 text-primary">
                                        <?php if ($items): ?>
                                            <?= e($items[0]['name_product']); ?> <span class="text-gray-600">&times;<?= (int) $items[0]['quantity_item']; ?></span>
                                            <?php if ($lain > 0): ?><span class="text-gray-600">&middot; +<?= $lain; ?> lainnya</span><?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-gray-600">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Depot" class="px-6 py-4 text-gray-700"><?= e(nama_depot($order)); ?></td>
                                    <td data-label="Total" class="px-6 py-4 text-right font-bold text-primary tabular-nums whitespace-nowrap"><?= rupiah($order['total_price']); ?></td>
                                    <td class="aksi px-6 py-2 text-right whitespace-nowrap">
                                        <a href="invoice.php?id=<?= (int) $order['id_order']; ?>" class="inline-flex items-center justify-center min-h-[44px] px-4 rounded-xl border border-secondary text-secondary font-semibold hover:bg-blue-100 active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2 transition">Invoice</a>
                                        <a href="detail_pesanan.php?id=<?= (int) $order['id_order']; ?>" class="inline-flex items-center justify-center min-h-[44px] px-4 ml-1 rounded-xl bg-secondary text-white font-semibold hover:bg-primary active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2 transition">Detail</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Halaman riwayat" class="flex justify-center items-center gap-2 mt-8 flex-wrap">
                        <?php if ($page > 1): ?>
                            <a href="<?= e(url_pesanan($page - 1)); ?>" aria-label="Halaman sebelumnya" class="w-11 h-11 rounded-xl border border-gray-300 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition">
                                <i class="fa-solid fa-chevron-left text-xs" aria-hidden="true"></i>
                            </a>
                        <?php else: ?>
                            <span class="w-11 h-11 rounded-xl border border-gray-200 bg-gray-50 flex items-center justify-center text-gray-300" aria-hidden="true"><i class="fa-solid fa-chevron-left text-xs"></i></span>
                        <?php endif; ?>

                        <?php
                        $tampil = [];
                        for ($i = 1; $i <= $total_pages; $i++) {
                            if ($i === 1 || $i === $total_pages || abs($i - $page) <= 1) {
                                $tampil[] = $i;
                            }
                        }
                        $sebelumnya = 0;
                        foreach ($tampil as $i):
                            if ($i - $sebelumnya > 1): ?>
                                <span class="w-6 text-center text-gray-600" aria-hidden="true">&hellip;</span>
                            <?php endif;
                            $sebelumnya = $i;
                            if ($i === $page): ?>
                                <span aria-current="page" class="w-11 h-11 rounded-xl bg-primary text-white flex items-center justify-center text-sm font-bold"><?= $i; ?></span>
                            <?php else: ?>
                                <a href="<?= e(url_pesanan($i)); ?>" aria-label="Halaman <?= $i; ?>" class="w-11 h-11 rounded-xl border border-gray-300 bg-white flex items-center justify-center text-gray-700 text-sm font-semibold hover:bg-gray-50 hover:text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition"><?= $i; ?></a>
                            <?php endif;
                        endforeach; ?>

                        <?php if ($page < $total_pages): ?>
                            <a href="<?= e(url_pesanan($page + 1)); ?>" aria-label="Halaman berikutnya" class="w-11 h-11 rounded-xl border border-gray-300 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition">
                                <i class="fa-solid fa-chevron-right text-xs" aria-hidden="true"></i>
                            </a>
                        <?php else: ?>
                            <span class="w-11 h-11 rounded-xl border border-gray-200 bg-gray-50 flex items-center justify-center text-gray-300" aria-hidden="true"><i class="fa-solid fa-chevron-right text-xs"></i></span>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </section>

    </main>

    <?php include '../layout/footer.php'; ?>
</body>
</html>