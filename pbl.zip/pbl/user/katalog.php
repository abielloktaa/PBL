<?php
session_start();
include __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['username']) || $_SESSION['id_role'] != "1") {
    header("location:../index.php?pesan=akses_ditolak");
    exit();
}

$username = $_SESSION['username'];
$id_user  = (int) $_SESSION['id_user'];

function e($s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function rupiah($n): string
{
    return 'Rp ' . number_format((float) $n, 0, ',', '.');
}

function db_all(mysqli $k, string $sql, string $types = '', array $params = []): array
{
    $st = $k->prepare($sql);
    if ($types !== '') {
        $st->bind_param($types, ...$params);
    }
    $st->execute();
    $res  = $st->get_result();
    $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    $st->close();
    return $rows;
}

function punya_foto($img): bool
{
    return !empty($img) && is_string($img) && strpos($img, 'dummy') === false;
}

function nama_depot(array $r): string
{
    return trim((string) ($r['depot'] ?? '')) !== '' ? $r['depot'] : ($r['agent_name'] ?? 'GalonKu');
}

// key => [label, pola nama produk]. Key lama 'Air Galon' tetap diterima.
$kategori_map = [
    'Semua'       => ['Semua', null],
    'Galon'       => ['Air Galon', '%Galon%'],
    'Gas LPG'     => ['Gas LPG', '%Gas%'],
    'Air Mineral' => ['Air Botol', '%Botol%'],
];
$urutan_map = [
    'Terbaru'  => 'product.id_product DESC',
    'Terlaris' => 'terjual DESC, product.id_product DESC',
    'Termurah' => 'product.price ASC',
    'Termahal' => 'product.price DESC',
    'A-Z'      => 'product.name_product ASC',
];

$search   = trim($_GET['search'] ?? '');
$kategori = $_GET['kategori'] ?? 'Semua';
if ($kategori === 'Air Galon') {
    $kategori = 'Galon';
}
if (!isset($kategori_map[$kategori])) {
    $kategori = 'Semua';
}
$sort = $_GET['sort'] ?? 'Terbaru';
if (!isset($urutan_map[$sort])) {
    $sort = 'Terbaru';
}
$hanya_tersedia = ($_GET['stok'] ?? '') === '1';
$page = max(1, (int) ($_GET['page'] ?? 1));

// Satu sumber WHERE untuk daftar produk dan saran pencarian.
function filter_produk(string $search, string $kategori, bool $hanya_tersedia, array $kategori_map): array
{
    $where  = ' WHERE 1=1';
    $types  = '';
    $params = [];
    if ($search !== '') {
        $like   = '%' . addcslashes($search, '%_\\') . '%';
        $where .= ' AND (product.name_product LIKE ? OR users.username LIKE ? OR users.depot LIKE ?)';
        $types .= 'sss';
        array_push($params, $like, $like, $like);
    }
    if ($kategori_map[$kategori][1] !== null) {
        $where   .= ' AND product.name_product LIKE ?';
        $types   .= 's';
        $params[] = $kategori_map[$kategori][1];
    }
    if ($hanya_tersedia) {
        $where .= ' AND product.stock > 0';
    }
    return [$where, $types, $params];
}

[$where, $types, $params] = filter_produk($search, $kategori, $hanya_tersedia, $kategori_map);

// Saran pencarian dikirim sebagai HTML yang sudah di-escape, jadi JavaScript tidak perlu merakit elemen.
if (($_GET['ajax'] ?? '') === 'saran') {
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    $saran = ($search !== '' && strlen($search) <= 80) ? db_all(
        $koneksi,
        "SELECT product.id_product, product.name_product, product.price, product.img,
                users.username AS agent_name, users.depot
         FROM product JOIN users ON product.id_agent = users.id_user" . $where .
        " ORDER BY (product.stock > 0) DESC, product.name_product ASC LIMIT 6",
        $types,
        $params
    ) : [];

    if (!$saran) {
        echo '<p class="px-4 py-3 text-sm text-gray-600">Tidak ada produk yang cocok.</p>';
        exit();
    }
    foreach ($saran as $i => $r): ?>
        <a id="saran-<?= $i; ?>" role="option" aria-selected="false" href="detail_produk.php?id=<?= (int) $r['id_product']; ?>"
           class="flex items-center gap-3 px-3 py-2 min-h-[44px] border-t border-gray-100 first:border-0 text-primary hover:bg-gray-50 aria-selected:bg-gray-100 focus:outline-none">
            <span class="w-12 h-12 flex-shrink-0 rounded-xl bg-gray-50 overflow-hidden">
                <?php if (punya_foto($r['img'])): ?><img src="../poto/<?= e(basename((string) $r['img'])); ?>" alt="" class="w-full h-full object-contain"><?php endif; ?>
            </span>
            <span class="min-w-0 flex-1">
                <span class="block text-sm font-semibold truncate"><?= e($r['name_product']); ?></span>
                <span class="block text-xs text-gray-600 truncate"><?= e(nama_depot($r)); ?></span>
            </span>
            <span class="text-sm font-bold whitespace-nowrap tabular-nums"><?= rupiah($r['price']); ?></span>
        </a>
    <?php endforeach;
    exit();
}

// Nilai default tidak ditulis ke URL.
function url_katalog(array $timpa = []): string
{
    global $search, $kategori, $sort, $hanya_tersedia, $page;
    $p = array_merge([
        'search'   => $search,
        'kategori' => $kategori,
        'sort'     => $sort,
        'stok'     => $hanya_tersedia ? '1' : '',
        'page'     => $page,
    ], $timpa);
    if ($p['kategori'] === 'Semua') unset($p['kategori']);
    if ($p['sort'] === 'Terbaru')   unset($p['sort']);
    if ($p['search'] === '')        unset($p['search']);
    if ($p['stok'] === '')          unset($p['stok']);
    if ((int) $p['page'] <= 1)      unset($p['page']);
    $qs = http_build_query($p);
    return 'katalog.php' . ($qs !== '' ? '?' . $qs : '');
}

function tombol_halaman(string $label, ?int $tujuan, string $aria, bool $aktif = false): void
{
    $kelas = 'min-w-[44px] h-11 px-3 rounded-xl flex items-center justify-center text-sm font-semibold';
    if ($aktif) {
        echo '<span aria-current="page" class="' . $kelas . ' bg-primary text-white">' . $label . '</span>';
    } elseif ($tujuan === null) {
        echo '<span aria-hidden="true" class="' . $kelas . ' border border-gray-200 bg-gray-50 text-gray-500">' . $label . '</span>';
    } else {
        echo '<a href="' . e(url_katalog(['page' => $tujuan])) . '" aria-label="' . e($aria) . '" class="' . $kelas
            . ' border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary">' . $label . '</a>';
    }
}

$limit = 8;

$hitung = db_all(
    $koneksi,
    "SELECT COUNT(*) AS total FROM product JOIN users ON product.id_agent = users.id_user" . $where,
    $types,
    $params
);
$total_data  = (int) ($hitung[0]['total'] ?? 0);
$total_pages = max(1, (int) ceil($total_data / $limit));
$page        = min($page, $total_pages);
$offset      = ($page - 1) * $limit;

$produk = db_all(
    $koneksi,
    "SELECT product.*, users.username AS agent_name, users.depot,
            (SELECT COALESCE(SUM(od.quantity_item), 0) FROM order_detail od WHERE od.id_product = product.id_product) AS terjual
     FROM product
     JOIN users ON product.id_agent = users.id_user" . $where .
    " ORDER BY (product.stock > 0) DESC, " . $urutan_map[$sort] .
    " LIMIT " . (int) $limit . " OFFSET " . (int) $offset,
    $types,
    $params
);

$ada_filter = $search !== '' || $kategori !== 'Semua' || $hanya_tersedia || $sort !== 'Terbaru';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Produk - GalonKu</title>
    <?php include '../layout/assets.php'; ?>
    <style>
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
    </style>
</head>
<body class="font-sans antialiased bg-surface flex flex-col min-h-screen">

    <?php include '../layout/navbar.php'; ?>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8 w-full flex-1">

        <header class="mb-6">
            <h1 class="text-2xl md:text-3xl font-extrabold text-primary mb-1">Katalog Produk</h1>
            <p class="text-sm text-gray-600">Air galon, gas LPG, dan air botol dari depot di GalonKu.</p>
        </header>

        <form id="form-katalog" action="katalog.php" method="GET" class="bg-white rounded-2xl p-3 md:p-4 mb-4 border border-gray-200 flex flex-col md:flex-row md:items-center gap-3">
            <input type="hidden" name="kategori" value="<?= e($kategori); ?>">

            <div class="flex-1 relative">
                <label for="cari" class="sr-only">Cari produk atau depot</label>
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm" aria-hidden="true"></i>
                <input id="cari" type="search" name="search" value="<?= e($search); ?>" placeholder="Cari nama produk atau depot" autocomplete="off"
                    role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="cari-saran"
                    class="w-full pl-11 pr-4 min-h-[44px] rounded-xl border border-gray-300 text-sm text-primary placeholder:text-gray-500 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none">
                <div id="cari-saran" role="listbox" aria-label="Saran produk" hidden
                     class="absolute z-40 left-0 right-0 top-full mt-2 max-h-80 overflow-y-auto bg-white border border-gray-200 rounded-xl shadow-soft"></div>
            </div>

            <div>
                <label for="urut" class="sr-only">Urutkan</label>
                <select id="urut" name="sort" class="w-full md:w-44 px-4 min-h-[44px] rounded-xl border border-gray-300 bg-white text-sm text-gray-700 cursor-pointer focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none">
                    <?php foreach (array_keys($urutan_map) as $opsi): ?>
                        <option value="<?= e($opsi); ?>" <?= $sort === $opsi ? 'selected' : ''; ?>>Urut: <?= e($opsi); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <label class="inline-flex items-center gap-2 px-1 min-h-[44px] text-sm text-gray-700 cursor-pointer whitespace-nowrap">
                <input id="stok-tersedia" type="checkbox" name="stok" value="1" <?= $hanya_tersedia ? 'checked' : ''; ?> class="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary">
                Hanya yang tersedia
            </label>

            <button type="submit" class="px-6 min-h-[44px] rounded-xl bg-primary text-white text-sm font-semibold hover:bg-secondary active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">Cari</button>
        </form>

        <nav aria-label="Kategori produk" class="flex gap-2 mb-5 overflow-x-auto no-scrollbar pb-1">
            <?php foreach ($kategori_map as $key => [$label]): $aktif = $kategori === $key; ?>
                <a href="<?= e(url_katalog(['kategori' => $key, 'page' => 1])); ?>" <?= $aktif ? 'aria-current="page"' : ''; ?>
                   class="inline-flex items-center px-5 min-h-[44px] rounded-full text-sm font-semibold whitespace-nowrap transition focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary
                          <?= $aktif ? 'bg-primary text-white' : 'bg-white text-gray-700 border border-gray-200 hover:border-primary hover:text-primary'; ?>">
                    <?= e($label); ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="flex flex-wrap items-center justify-between gap-2 mb-4 text-sm text-gray-700" aria-live="polite">
            <p>
                <?php if ($total_data > 0): ?>
                    Menampilkan <strong class="text-primary tabular-nums"><?= $offset + 1; ?>&ndash;<?= $offset + count($produk); ?></strong>
                    dari <strong class="text-primary tabular-nums"><?= $total_data; ?></strong> produk<?php if ($search !== ''): ?> untuk &ldquo;<?= e($search); ?>&rdquo;<?php endif; ?>
                <?php else: ?>
                    0 produk ditemukan
                <?php endif; ?>
            </p>
            <?php if ($ada_filter): ?>
                <a href="katalog.php" class="inline-flex items-center min-h-[44px] font-semibold text-secondary hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary rounded-xl">Reset filter</a>
            <?php endif; ?>
        </div>

        <?php if (empty($produk)): ?>
            <div class="bg-white p-10 rounded-2xl text-center border border-gray-200">
                <p class="font-semibold text-primary mb-1">Produk tidak ditemukan</p>
                <p class="text-sm text-gray-600 mb-4">Periksa ejaan kata kunci, ganti jenis produk, atau reset filter.</p>
                <?php if ($ada_filter): ?>
                    <a href="katalog.php" class="inline-flex items-center px-5 min-h-[44px] rounded-xl bg-primary text-white text-sm font-semibold hover:bg-secondary focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">Tampilkan semua produk</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                <?php foreach ($produk as $row):
                    $stok    = (int) $row['stock'];
                    $habis   = $stok <= 0;
                    $terjual = (int) $row['terjual'];
                    if ($habis) {
                        $status = ['Stok habis', 'text-red-700', 'Belum bisa dipesan'];
                    } elseif ($stok <= 10) {
                        $status = ['Segera habis', 'text-amber-800', 'Sisa ' . $stok];
                    } else {
                        $status = ['Tersedia', 'text-green-800', 'Sisa ' . $stok];
                    }
                ?>
                    <article class="flex flex-col h-full bg-white rounded-2xl border border-gray-200 overflow-hidden transition-colors hover:border-gray-400">
                        <a href="detail_produk.php?id=<?= (int) $row['id_product']; ?>" class="block focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-secondary">
                            <div class="h-40 sm:h-44 flex items-center justify-center overflow-hidden bg-white border-b border-gray-100">
                                <?php if (punya_foto($row['img'])): ?>
                                    <img src="../poto/<?= e($row['img']); ?>" alt="<?= e($row['name_product']); ?>" loading="lazy"
                                         class="w-full h-full object-contain p-4 <?= $habis ? 'grayscale opacity-50' : ''; ?>">
                                <?php else: ?>
                                    <i class="fa-solid fa-droplet text-secondary text-5xl opacity-40" aria-hidden="true"></i>
                                <?php endif; ?>
                            </div>
                            <div class="p-4 pb-2">
                                <p class="text-xs text-gray-600 truncate"><?= e(nama_depot($row)); ?></p>
                                <h2 class="mt-1 text-sm font-semibold leading-snug text-primary line-clamp-2 min-h-[2.5rem]" title="<?= e($row['name_product']); ?>"><?= e($row['name_product']); ?></h2>
                                <p class="mt-2 text-lg font-bold text-primary tabular-nums"><?= rupiah($row['price']); ?></p>
                                <p class="mt-2 text-xs"><span class="font-semibold <?= $status[1]; ?>"><?= e($status[0]); ?></span> <span class="text-gray-600">&middot; <?= e($status[2]); ?></span></p>
                                <?php if ($terjual > 0): ?>
                                    <p class="mt-1 text-xs text-gray-600"><?= $terjual; ?> terjual</p>
                                <?php endif; ?>
                            </div>
                        </a>
                        <form method="post" action="../action/actionkeranjang.php" class="mt-auto p-4 pt-2">
                            <input type="hidden" name="id_produk" value="<?= (int) $row['id_product']; ?>">
                            <input type="hidden" name="qty" value="1">
                            <?php if ($habis): ?>
                                <button type="button" disabled class="w-full min-h-[44px] rounded-xl bg-gray-100 text-gray-700 text-sm font-semibold cursor-not-allowed">Stok habis</button>
                            <?php else: ?>
                                <button type="submit" name="tambah_keranjang" value="1" aria-label="Tambah <?= e($row['name_product']); ?> ke keranjang"
                                        class="w-full min-h-[44px] rounded-xl bg-primary text-white text-sm font-semibold hover:bg-secondary active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">+ Keranjang</button>
                            <?php endif; ?>
                        </form>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($total_pages > 1): ?>
            <nav aria-label="Halaman produk" class="flex justify-center items-center gap-2 mt-8 flex-wrap">
                <?php
                tombol_halaman('Sebelumnya', $page > 1 ? $page - 1 : null, 'Halaman sebelumnya');
                $sebelumnya = 0;
                for ($i = 1; $i <= $total_pages; $i++) {
                    if ($i !== 1 && $i !== $total_pages && abs($i - $page) > 1) {
                        continue;
                    }
                    if ($i - $sebelumnya > 1) {
                        echo '<span class="w-6 text-center text-gray-600" aria-hidden="true">&hellip;</span>';
                    }
                    $sebelumnya = $i;
                    tombol_halaman((string) $i, $i, 'Halaman ' . $i, $i === $page);
                }
                tombol_halaman('Berikutnya', $page < $total_pages ? $page + 1 : null, 'Halaman berikutnya');
                ?>
            </nav>
        <?php endif; ?>

    </main>

    <script>
        (() => {
            const form = document.getElementById('form-katalog');
            const input = document.getElementById('cari');
            const panel = document.getElementById('cari-saran');
            const stok = document.getElementById('stok-tersedia');
            const urut = document.getElementById('urut');
            let timer, ctrl;

            const opsi = () => [...panel.querySelectorAll('[role=option]')];
            const tutup = () => {
                panel.hidden = true;
                input.setAttribute('aria-expanded', 'false');
                input.removeAttribute('aria-activedescendant');
            };
            const pilih = i => {
                const o = opsi();
                if (!o.length) return;
                o.forEach(el => el.setAttribute('aria-selected', 'false'));
                const el = o[(i + o.length) % o.length];
                el.setAttribute('aria-selected', 'true');
                input.setAttribute('aria-activedescendant', el.id);
            };

            const muat = async () => {
                const q = input.value.trim();
                if (!q) return tutup();
                ctrl?.abort();
                ctrl = new AbortController();
                const p = new URLSearchParams({ ajax: 'saran', search: q, kategori: form.elements.kategori.value, stok: stok.checked ? '1' : '' });
                try {
                    const r = await fetch('katalog.php?' + p, { signal: ctrl.signal });
                    if (!r.ok) throw r;
                    const html = await r.text();
                    if (input.value.trim() !== q) return;
                    panel.innerHTML = html;
                    panel.hidden = false;
                    input.setAttribute('aria-expanded', 'true');
                } catch (err) {
                    if (err.name !== 'AbortError') tutup();
                }
            };

            input.addEventListener('input', () => {
                clearTimeout(timer);
                timer = setTimeout(muat, 180);
            });
            input.addEventListener('keydown', ev => {
                if (panel.hidden) return;
                const o = opsi();
                const i = o.findIndex(el => el.getAttribute('aria-selected') === 'true');
                if (ev.key === 'ArrowDown') { ev.preventDefault(); pilih(i + 1); }
                else if (ev.key === 'ArrowUp') { ev.preventDefault(); pilih(i < 0 ? -1 : i - 1); }
                else if (ev.key === 'Enter' && i >= 0) { ev.preventDefault(); location.href = o[i].href; }
                else if (ev.key === 'Escape') tutup();
            });
            document.addEventListener('click', ev => { if (!form.contains(ev.target)) tutup(); });
            [urut, stok].forEach(el => el.addEventListener('change', () => form.submit()));
        })();
    </script>

    <?php include '../layout/keranjang-popup.php'; ?>

    <?php include '../layout/footer.php'; ?>
</body>
</html>