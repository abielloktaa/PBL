<?php
session_start();
include __DIR__ . '/../koneksi.php';

if (!isset($_SESSION['username']) || $_SESSION['id_role'] != "1") {
    header("location:../login.php?pesan=belum_login");
    exit();
}

date_default_timezone_set('Asia/Jakarta');

$username = $_SESSION['username'];
$id_user  = (int) $_SESSION['id_user'];

function e($s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function rupiah($n): string
{
    return 'Rp ' . number_format((float) $n, 0, ',', '.');
}

function db_all(mysqli $k, string $sql, string $types = '', array $params = []): array
{
    $st = $k->prepare($sql);
    if ($types !== '') {
        $st->bind_param($types, ...$params);
    }
    $st->execute();
    $res  = $st->get_result();
    $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    $st->close();
    return $rows;
}

function db_one(mysqli $k, string $sql, string $types = '', array $params = []): ?array
{
    $rows = db_all($k, $sql, $types, $params);
    return $rows[0] ?? null;
}

function punya_foto($img): bool
{
    return !empty($img) && is_string($img) && strpos($img, 'dummy') === false;
}

$hari  = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
$bulan = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

$jam    = (int) date('G');
$sapaan = $jam < 11 ? 'Selamat pagi' : ($jam < 15 ? 'Selamat siang' : ($jam < 18 ? 'Selamat sore' : 'Selamat malam'));
$tanggal_label = $hari[(int) date('w')] . ', ' . date('j') . ' ' . $bulan[(int) date('n')] . ' ' . date('Y');

$jumlah_keranjang = 0;
if (!empty($_SESSION['keranjang']) && is_array($_SESSION['keranjang'])) {
    $jumlah_keranjang = (int) array_sum($_SESSION['keranjang']);
}

$login_baru = isset($_GET['pesan']) && $_GET['pesan'] === 'login_berhasil';

$awal_bulan  = date('Y-m-01 00:00:00');
$bulan_depan = date('Y-m-01 00:00:00', strtotime('first day of next month'));

$bln = db_one(
    $koneksi,
    "SELECT COALESCE(SUM(total_price), 0) AS total, COUNT(*) AS jumlah
     FROM orders WHERE id_user = ? AND order_date >= ? AND order_date < ?",
    'iss',
    [$id_user, $awal_bulan, $bulan_depan]
);
$belanja_bulan_ini  = (float) ($bln['total'] ?? 0);
$transaksi_bulan_ini = (int) ($bln['jumlah'] ?? 0);

$tot = db_one(
    $koneksi,
    "SELECT
        COALESCE(SUM(CASE WHEN p.name_product LIKE '%Galon%' THEN od.quantity_item END), 0) AS galon,
        COALESCE(SUM(CASE WHEN p.name_product LIKE '%Gas%'   THEN od.quantity_item END), 0) AS gas
     FROM order_detail od
     JOIN orders o  ON od.id_order = o.id_order
     JOIN product p ON od.id_product = p.id_product
     WHERE o.id_user = ?",
    'i',
    [$id_user]
);
$total_galon = (int) ($tot['galon'] ?? 0);
$total_gas   = (int) ($tot['gas'] ?? 0);

$pesanan_aktif = db_all(
    $koneksi,
    "SELECT o.id_order, o.order_date, o.total_price
     FROM orders o
     WHERE o.id_user = ?
       AND EXISTS (SELECT 1 FROM order_detail od WHERE od.id_order = o.id_order AND od.status <> 'SELESAI')
     ORDER BY o.order_date DESC",
    'i',
    [$id_user]
);
$jumlah_aktif = count($pesanan_aktif);

$tahap_map = ['MENUNGGU KONFIRMASI AGENT' => 0, 'DIPROSES' => 1, 'PENGANTARAN' => 2, 'SELESAI' => 3];
$status_label = [
    'MENUNGGU KONFIRMASI AGENT' => 'Menunggu konfirmasi agent',
    'DIPROSES'                  => 'Sedang diproses',
    'PENGANTARAN'               => 'Dalam pengantaran',
    'SELESAI'                   => 'Selesai',
];
$langkah = ['Menunggu', 'Diproses', 'Diantar', 'Selesai'];

$order_utama = null;
$item_utama  = [];
$tahap       = 0;
$status_utama = 'MENUNGGU KONFIRMASI AGENT';
if ($jumlah_aktif > 0) {
    $order_utama = $pesanan_aktif[0];
    $item_utama  = db_all(
        $koneksi,
        "SELECT od.quantity_item, od.status, p.name_product
         FROM order_detail od
         JOIN product p ON od.id_product = p.id_product
         WHERE od.id_order = ?",
        'i',
        [(int) $order_utama['id_order']]
    );
    // Tahap pesanan mengikuti status paling awal yang belum selesai
    $tahap = 3;
    foreach ($item_utama as $it) {
        $t = $tahap_map[$it['status']] ?? 0;
        if ($t < $tahap) {
            $tahap = $t;
            $status_utama = $it['status'];
        }
    }
    if ($tahap === 3) {
        $status_utama = 'SELESAI';
    }
}

$beli_lagi = db_all(
    $koneksi,
    "SELECT p.id_product, p.name_product, p.price, p.stock, p.img, SUM(od.quantity_item) AS total_qty
     FROM order_detail od
     JOIN orders o  ON od.id_order = o.id_order
     JOIN product p ON od.id_product = p.id_product
     WHERE o.id_user = ?
     GROUP BY p.id_product, p.name_product, p.price, p.stock, p.img
     ORDER BY total_qty DESC
     LIMIT 3",
    'i',
    [$id_user]
);

$now = date('Y-m-d H:i:s');
$today = date('Y-m-d');
$reminder = db_one(
    $koneksi,
    "SELECT id_reminder, date, time FROM reminder
     WHERE id_user = ? AND TIMESTAMP(date, time) >= ?
     ORDER BY date ASC, time ASC LIMIT 1",
    'is',
    [$id_user, $now]
);

$rem_selisih = null;
$rem_hari    = '';
$rem_jam     = '';
$rem_tanggal = '';
if ($reminder) {
    $rem_selisih = (int) (new DateTime($today))->diff(new DateTime($reminder['date']))->format('%r%a');
    $rem_hari    = $rem_selisih === 0 ? 'Hari ini' : ($rem_selisih === 1 ? 'Besok' : $rem_selisih . ' hari lagi');
    $rem_jam     = substr($reminder['time'], 0, 5);
    $ts          = strtotime($reminder['date']);
    $rem_tanggal = $hari[(int) date('w', $ts)] . ', ' . date('j', $ts) . ' ' . $bulan[(int) date('n', $ts)] . ' ' . date('Y', $ts);
}
$tampil_popup = $reminder && $rem_selisih <= 1 && !$login_baru;

$produk = db_all(
    $koneksi,
    "SELECT product.*, users.username AS agent_name,
            (SELECT COALESCE(SUM(od.quantity_item), 0) FROM order_detail od WHERE od.id_product = product.id_product) AS terjual
     FROM product
     JOIN users ON product.id_agent = users.id_user
     ORDER BY (product.stock > 0) DESC, terjual DESC, product.id_product DESC
     LIMIT 10"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - GalonKu</title>
    <?php include '../layout/assets.php'; ?>
    <style>
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
    </style>
</head>

<body class="font-sans antialiased bg-surface flex flex-col min-h-screen">

    <?php include '../layout/navbar.php'; ?>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8 w-full flex-1">

        <header class="mb-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 mb-5">
                <div>
                    <p class="text-sm text-slate-600 font-medium mb-1"><?= e($tanggal_label); ?></p>
                    <h1 class="text-2xl md:text-3xl font-bold text-primary">
                        <?= e($sapaan); ?>, <span class="capitalize"><?= e($username); ?></span>
                    </h1>
                </div>
                <a href="katalog.php" class="self-start mt-1 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-secondary transition">
                    Belanja sekarang
                </a>
            </div>
            <div class="flex flex-wrap items-center gap-x-6 gap-y-2 pt-4 border-t border-gray-200">
                <div>
                    <span class="text-2xl font-bold text-primary"><?= rupiah($belanja_bulan_ini); ?></span>
                    <span class="ml-2 text-sm text-slate-600 font-medium"><?= $transaksi_bulan_ini; ?> transaksi bulan ini</span>
                </div>
                <div class="w-px h-5 bg-gray-200 hidden sm:block" aria-hidden="true"></div>
                <div>
                    <span class="text-2xl font-bold text-primary"><?= $jumlah_aktif; ?></span>
                    <span class="ml-2 text-sm text-slate-600 font-medium">pesanan aktif</span>
                </div>
                <div class="w-px h-5 bg-gray-200 hidden sm:block" aria-hidden="true"></div>
                <div>
                    <span class="text-sm text-slate-600 font-medium"><?= $total_galon; ?> galon &middot; <?= $total_gas; ?> gas terbeli</span>
                </div>
            </div>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 mb-8">

            <div class="lg:col-span-2 space-y-4">

                <section aria-labelledby="judul-pesanan" class="bg-white border border-gray-200 rounded-xl p-5 md:p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h2 id="judul-pesanan" class="text-base font-bold text-primary">Pesanan berlangsung</h2>
                        <a href="pesanan.php" class="text-sm font-semibold text-secondary hover:underline">Semua pesanan</a>
                    </div>

                    <?php if ($order_utama): ?>
                        <div class="flex flex-wrap items-start justify-between gap-3">
                            <div>
                                <p class="font-bold text-primary">#ORD-<?= (int) $order_utama['id_order']; ?></p>
                                <p class="text-sm text-slate-600 mt-0.5"><?= e(date('d M Y, H:i', strtotime($order_utama['order_date']))); ?></p>
                            </div>
                            <span class="inline-flex items-center bg-blue-50 text-secondary text-xs font-semibold px-3 py-1 rounded-md border border-blue-100">
                                <?= e($status_label[$status_utama] ?? $status_utama); ?>
                            </span>
                        </div>

                        <ol class="flex items-start mt-6 mb-2">
                            <?php foreach ($langkah as $i => $nama): ?>
                                <li class="flex-1 flex flex-col items-center relative" <?= $i === $tahap ? 'aria-current="step"' : ''; ?>>
                                    <?php if ($i > 0): ?>
                                        <span class="absolute top-3.5 right-1/2 w-full h-0.5 <?= $i <= $tahap ? 'bg-secondary' : 'bg-gray-200'; ?>" aria-hidden="true"></span>
                                    <?php endif; ?>
                                    <span class="relative z-10 w-7 h-7 rounded-full flex items-center justify-center text-xs <?= $i < $tahap ? 'bg-secondary text-white' : ($i === $tahap ? 'bg-secondary text-white ring-4 ring-blue-100' : 'bg-gray-200 text-slate-600'); ?>">
                                        <i class="fa-solid <?= $i < $tahap ? 'fa-check' : 'fa-circle'; ?> <?= $i < $tahap ? '' : 'text-[6px]'; ?>" aria-hidden="true"></i>
                                    </span>
                                    <span class="mt-2 text-xs <?= $i <= $tahap ? 'text-primary font-bold' : 'text-slate-500 font-medium'; ?>"><?= e($nama); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ol>

                        <ul class="mt-4 pt-4 border-t border-gray-100 space-y-1.5 text-sm">
                            <?php foreach (array_slice($item_utama, 0, 3) as $it): ?>
                                <li class="flex justify-between gap-3">
                                    <span class="truncate text-slate-800 font-medium"><?= e($it['name_product']); ?></span>
                                    <span class="flex-shrink-0 text-slate-600 font-semibold">&times; <?= (int) $it['quantity_item']; ?></span>
                                </li>
                            <?php endforeach; ?>
                            <?php if (count($item_utama) > 3): ?>
                                <li class="text-xs text-slate-500">+<?= count($item_utama) - 3; ?> produk lainnya</li>
                            <?php endif; ?>
                        </ul>

                        <div class="flex flex-wrap items-center justify-between gap-3 mt-4">
                            <p class="text-sm text-slate-600">Total belanja <span class="font-extrabold text-primary text-base ml-1"><?= rupiah($order_utama['total_price']); ?></span></p>
                            <a href="detail_pesanan.php?id=<?= (int) $order_utama['id_order']; ?>" class="px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-secondary transition">Lihat detail</a>
                        </div>

                        <?php if ($jumlah_aktif > 1): ?>
                            <a href="pesanan.php" class="block mt-3 text-sm text-slate-700 bg-slate-50 border border-slate-200/70 rounded-lg px-4 py-2.5 hover:bg-slate-100 transition">
                                Ada <?= $jumlah_aktif - 1; ?> pesanan lain yang masih berjalan.
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="text-center py-8">
                            <span class="w-12 h-12 mx-auto bg-blue-50 text-secondary flex items-center justify-center mb-3 rounded-xl"><i class="fa-solid fa-box-open text-xl" aria-hidden="true"></i></span>
                            <p class="font-semibold text-primary mb-1">Belum ada pesanan yang berjalan</p>
                            <p class="text-sm text-slate-600 mb-4">Pesanan galon atau gas yang sedang diproses akan tampil di sini.</p>
                            <a href="katalog.php" class="inline-block px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-secondary transition">Pesan galon atau gas</a>
                        </div>
                    <?php endif; ?>
                </section>

                <section aria-labelledby="judul-beli-lagi" class="bg-white border border-gray-200 rounded-xl p-5 md:p-6">
                    <div class="flex items-center justify-between mb-2">
                        <h2 id="judul-beli-lagi" class="text-base font-bold text-primary">Beli lagi</h2>
                        <a href="riwayat.php" class="text-sm font-semibold text-secondary hover:underline">Riwayat</a>
                    </div>

                    <?php if (!empty($beli_lagi)): ?>
                        <ul class="divide-y divide-gray-100">
                            <?php foreach ($beli_lagi as $b): $habis = (int) $b['stock'] <= 0; ?>
                                <li class="flex items-center gap-3 py-3">
                                    <div class="w-11 h-11 rounded-lg bg-gray-50 border border-gray-100 flex items-center justify-center overflow-hidden flex-shrink-0">
                                        <?php if (punya_foto($b['img'])): ?>
                                            <img src="../poto/<?= e($b['img']); ?>" alt="" class="w-full h-full object-cover" loading="lazy">
                                        <?php else: ?>
                                            <i class="fa-solid fa-droplet text-secondary text-lg" aria-hidden="true"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="font-bold text-sm text-primary truncate"><?= e($b['name_product']); ?></p>
                                        <p class="text-sm text-slate-600">Dibeli <?= (int) $b['total_qty']; ?>x &middot; <span class="font-semibold text-primary"><?= rupiah($b['price']); ?></span></p>
                                    </div>
                                    <form method="post" action="../action/actionkeranjang.php" class="flex-shrink-0">
                                        <input type="hidden" name="id_produk" value="<?= (int) $b['id_product']; ?>">
                                        <input type="hidden" name="qty" value="1">
                                        <?php if ($habis): ?>
                                            <button type="button" disabled class="px-3.5 py-2 rounded-lg bg-gray-100 text-slate-500 text-sm font-medium cursor-not-allowed">Habis</button>
                                        <?php else: ?>
                                            <button type="submit" name="tambah_keranjang" value="1" class="px-3.5 py-2 rounded-lg border border-primary text-primary text-sm font-semibold hover:bg-primary hover:text-white transition">Pesan lagi</button>
                                        <?php endif; ?>
                                    </form>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-sm text-slate-600 py-4">Produk yang sering Anda beli akan muncul di sini agar pesanan ulang lebih cepat.</p>
                    <?php endif; ?>
                </section>
            </div>

            <aside class="space-y-4">

                <section aria-labelledby="judul-pengingat" class="bg-white border border-gray-200 rounded-xl p-5">
                    <div class="flex items-center justify-between mb-3">
                        <h2 id="judul-pengingat" class="text-base font-bold text-primary">Pengingat isi ulang</h2>
                        <a href="reminder.php" class="text-xs font-semibold text-secondary hover:underline">Kelola</a>
                    </div>
                    <?php if ($reminder): ?>
                        <div class="flex items-start gap-3 bg-blue-50/60 border border-blue-100 rounded-lg p-3.5">
                            <span class="w-9 h-9 rounded-lg bg-secondary text-white flex items-center justify-center flex-shrink-0 mt-0.5">
                                <i class="fa-solid fa-bell text-sm" aria-hidden="true"></i>
                            </span>
                            <div class="min-w-0">
                                <p class="font-bold text-primary text-base leading-tight"><?= e($rem_hari); ?> &middot; <?= e($rem_jam); ?> WIB</p>
                                <p class="text-xs text-slate-600 mt-1"><?= e($rem_tanggal); ?></p>
                            </div>
                        </div>
                        <a href="reminder.php" class="block mt-3 text-center px-4 py-2 rounded-lg border border-gray-300 text-primary text-sm font-semibold hover:bg-gray-50 transition">
                            Atur jadwal pengingat
                        </a>
                    <?php else: ?>
                        <p class="text-sm text-slate-600 mb-4 leading-relaxed">Atur jadwal pengingat rutin agar stok air minum dan gas LPG tidak habis mendadak.</p>
                        <a href="reminder.php" class="block text-center px-4 py-2.5 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-secondary transition">
                            Pasang pengingat
                        </a>
                    <?php endif; ?>
                </section>

                <section aria-labelledby="judul-layanan" class="bg-white border border-gray-200 rounded-xl p-5">
                    <h2 id="judul-layanan" class="text-base font-bold text-primary mb-3">Informasi layanan</h2>
                    <ul class="space-y-3.5 text-sm">
                        <li class="flex items-start gap-3">
                            <span class="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center flex-shrink-0 mt-0.5">
                                <i class="fa-solid fa-clock text-xs" aria-hidden="true"></i>
                            </span>
                            <div>
                                <p class="font-semibold text-primary">Jam Pengantaran</p>
                                <p class="text-slate-600 text-xs mt-0.5 leading-relaxed">Setiap hari pukul 08.00 - 17.00 WIB. Pesanan sore dikirim tepat waktu.</p>
                            </div>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="w-7 h-7 rounded-lg bg-blue-50 text-secondary flex items-center justify-center flex-shrink-0 mt-0.5">
                                <i class="fa-solid fa-shield-check text-xs" aria-hidden="true"></i>
                            </span>
                            <div>
                                <p class="font-semibold text-primary">Jaminan Kualitas</p>
                                <p class="text-slate-600 text-xs mt-0.5 leading-relaxed">Galon higienis terstandar dan tabung gas LPG resmi bersegel aman.</p>
                            </div>
                        </li>
                        <li class="flex items-start gap-3">
                            <span class="w-7 h-7 rounded-lg bg-orange-50 text-brandOrange flex items-center justify-center flex-shrink-0 mt-0.5">
                                <i class="fa-solid fa-headset text-xs" aria-hidden="true"></i>
                            </span>
                            <div>
                                <p class="font-semibold text-primary">Kendala Pesanan?</p>
                                <p class="text-slate-600 text-xs mt-0.5 leading-relaxed">Hubungi depot pengantar langsung melalui rincian pada menu pesanan.</p>
                            </div>
                        </li>
                    </ul>
                    <div class="mt-4 pt-3.5 border-t border-gray-100 flex items-center justify-between">
                        <span class="text-xs text-slate-500">Lihat semua transaksi</span>
                        <a href="riwayat.php" class="text-xs font-semibold text-secondary hover:underline">Riwayat &rarr;</a>
                    </div>
                </section>
            </aside>
        </div>

        <section aria-labelledby="judul-produk" class="mb-4">
            <div class="flex items-center justify-between mb-4">
                <h2 id="judul-produk" class="text-lg font-bold text-primary">Produk populer</h2>
                <div class="flex items-center gap-3">
                    <a href="katalog.php" class="text-sm font-semibold text-secondary hover:underline">Lihat semua</a>
                    <div class="flex gap-1.5">
                        <button type="button" data-geser="-1" aria-label="Geser produk ke kiri" class="w-8 h-8 rounded-lg border border-gray-300 bg-white flex items-center justify-center text-slate-700 hover:bg-gray-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition">
                            <i class="fa-solid fa-chevron-left text-xs" aria-hidden="true"></i>
                        </button>
                        <button type="button" data-geser="1" aria-label="Geser produk ke kanan" class="w-8 h-8 rounded-lg border border-gray-300 bg-white flex items-center justify-center text-slate-700 hover:bg-gray-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition">
                            <i class="fa-solid fa-chevron-right text-xs" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
            </div>

            <?php if (empty($produk)): ?>
                <div class="bg-white border border-gray-200 rounded-xl p-8 text-center">
                    <p class="font-semibold text-primary mb-1">Belum ada produk</p>
                    <p class="text-sm text-slate-600">Produk dari depot akan tampil di sini setelah ditambahkan.</p>
                </div>
            <?php else: ?>
                <div id="carouselContainer" class="flex gap-3 overflow-x-auto snap-x snap-mandatory scroll-smooth no-scrollbar pb-2">
                    <?php foreach ($produk as $row):
                        $stok  = (int) $row['stock'];
                        $habis = $stok <= 0;
                        $tipis = !$habis && $stok <= 10;
                    ?>
                        <article data-card class="w-56 flex-shrink-0 snap-start bg-white border border-gray-200 rounded-xl p-3 flex flex-col">
                            <a href="detail_produk.php?id=<?= (int) $row['id_product']; ?>" class="block focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary rounded-lg">
                                <div class="relative h-32 bg-gray-50 rounded-lg mb-2.5 flex items-center justify-center overflow-hidden">
                                    <?php if (punya_foto($row['img'])): ?>
                                        <img src="../poto/<?= e($row['img']); ?>" alt="<?= e($row['name_product']); ?>" class="w-full h-full object-cover <?= $habis ? 'opacity-40' : ''; ?>" loading="lazy">
                                    <?php else: ?>
                                        <i class="fa-solid fa-droplet text-secondary text-3xl opacity-40" aria-hidden="true"></i>
                                    <?php endif; ?>
                                    <?php if ($habis): ?>
                                        <span class="absolute top-2 left-2 bg-slate-800 text-white text-xs font-semibold px-2 py-0.5 rounded">Habis</span>
                                    <?php elseif ($tipis): ?>
                                        <span class="absolute top-2 left-2 bg-amber-100 text-amber-900 border border-amber-300/60 text-xs font-semibold px-2 py-0.5 rounded">Stok tipis</span>
                                    <?php endif; ?>
                                </div>
                                <h3 class="font-bold text-sm text-primary truncate" title="<?= e($row['name_product']); ?>"><?= e($row['name_product']); ?></h3>
                                <p class="text-xs text-slate-600 truncate mt-1">
                                    <i class="fa-solid fa-store mr-1 text-secondary" aria-hidden="true"></i><?= e($row['agent_name'] ?? 'GalonKu'); ?>
                                    <?php if ((int) $row['terjual'] > 0): ?>
                                        &middot; Terjual <?= (int) $row['terjual']; ?>
                                    <?php endif; ?>
                                </p>
                            </a>

                            <div class="flex items-center justify-between gap-2 mt-auto pt-3 border-t border-gray-100">
                                <div>
                                    <p class="text-xs text-slate-500 font-medium">Stok <?= $stok; ?></p>
                                    <p class="font-bold text-primary text-sm"><?= rupiah($row['price']); ?></p>
                                </div>
                                <form method="post" action="../action/actionkeranjang.php">
                                    <input type="hidden" name="id_produk" value="<?= (int) $row['id_product']; ?>">
                                    <input type="hidden" name="qty" value="1">
                                    <?php if ($habis): ?>
                                        <button type="button" disabled aria-label="<?= e($row['name_product']); ?> habis" class="w-9 h-9 rounded-lg bg-gray-100 text-gray-400 flex items-center justify-center cursor-not-allowed">
                                            <i class="fa-solid fa-cart-plus text-sm" aria-hidden="true"></i>
                                        </button>
                                    <?php else: ?>
                                        <button type="submit" name="tambah_keranjang" value="1" aria-label="Tambah <?= e($row['name_product']); ?> ke keranjang" class="w-9 h-9 rounded-lg bg-secondary text-white flex items-center justify-center hover:bg-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">
                                            <i class="fa-solid fa-cart-plus text-sm" aria-hidden="true"></i>
                                        </button>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php if ($login_baru): ?>
        <div id="loginToast" role="status" class="fixed top-24 right-4 z-[90] max-w-xs bg-white border border-gray-200 rounded-xl shadow-lg px-4 py-3 flex items-center gap-3">
            <span class="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
            <p class="text-sm text-primary">Berhasil masuk. Selamat datang kembali, <span class="font-semibold capitalize"><?= e($username); ?></span>.</p>
        </div>
    <?php endif; ?>

    <?php if ($tampil_popup): ?>
        <div id="reminderModal" role="dialog" aria-modal="true" aria-labelledby="judul-popup" class="hidden fixed inset-0 z-[100] items-center justify-center bg-black/50 p-4">
            <div class="bg-white rounded-xl p-6 max-w-sm w-full text-center shadow-xl border border-gray-200">
                <span class="w-12 h-12 mx-auto rounded-lg bg-blue-50 text-secondary flex items-center justify-center mb-4"><i class="fa-solid fa-bell text-xl" aria-hidden="true"></i></span>
                <h2 id="judul-popup" class="text-xl font-bold text-primary mb-2">Jadwal belanja <?= e(strtolower($rem_hari)); ?></h2>
                <p class="text-sm text-slate-600 mb-6 leading-relaxed">Pengingat Anda diatur pukul <?= e($rem_jam); ?> WIB. Pesan sekarang agar stok galon dan gas Anda tidak habis.</p>
                <div class="flex flex-col gap-2">
                    <a href="katalog.php" class="w-full bg-primary text-white py-2.5 rounded-lg font-semibold hover:bg-secondary transition">Pesan sekarang</a>
                    <button type="button" data-tutup class="w-full bg-gray-100 text-slate-700 py-2.5 rounded-lg font-semibold hover:bg-gray-200 transition">Nanti saja</button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script>
        (function () {
            // Carousel produk
            var track = document.getElementById('carouselContainer');
            document.querySelectorAll('[data-geser]').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    if (!track) return;
                    var card = track.querySelector('[data-card]');
                    var langkah = card ? card.offsetWidth + 12 : 236;
                    track.scrollBy({ left: Number(btn.dataset.geser) * langkah, behavior: 'smooth' });
                });
            });

            // Toast login: hilang otomatis, lalu bersihkan ?pesan= dari URL agar tidak muncul lagi saat refresh
            var toast = document.getElementById('loginToast');
            if (toast) {
                setTimeout(function () { toast.style.display = 'none'; }, 4500);
                history.replaceState(null, '', location.pathname);
            }

            // Popup pengingat: tampil sekali per hari per akun
            var modal = document.getElementById('reminderModal');
            if (modal) {
                var key = 'galonku_rem_<?= $id_user; ?>_<?= $today; ?>';
                var sudah = false;
                try { sudah = localStorage.getItem(key) === '1'; } catch (e) {}
                var tutup = function () {
                    modal.classList.add('hidden');
                    modal.classList.remove('flex');
                    try { localStorage.setItem(key, '1'); } catch (e) {}
                };
                if (!sudah) {
                    modal.classList.remove('hidden');
                    modal.classList.add('flex');
                    var tombol = modal.querySelector('[data-tutup]');
                    if (tombol) tombol.focus();
                }
                modal.querySelectorAll('[data-tutup]').forEach(function (b) { b.addEventListener('click', tutup); });
                document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !modal.classList.contains('hidden')) tutup(); });
            }
        })();
    </script>

    <?php include '../layout/keranjang-popup.php'; ?>

    <?php include '../layout/footer.php'; ?>
</body>
</html>
