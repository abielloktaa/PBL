<?php
// Popup konfirmasi "tambah ke keranjang". Di-include sebelum footer pada halaman yang punya tombol keranjang.
// Menangkap semua form yang mengarah ke actionkeranjang.php dan mengirimnya lewat AJAX tanpa pindah halaman.
?>
<style>
    /* Transisi backdrop popup keranjang */
    #keranjangModal {
        transition: opacity 200ms ease-out;
    }
    #keranjangModal.modal-masuk   { opacity: 1; pointer-events: auto; }
    #keranjangModal.modal-keluar  { opacity: 0; pointer-events: none; }

    /* Transisi kartu dialog popup keranjang */
    #keranjangCard {
        transition: opacity 200ms ease-out, transform 200ms ease-out;
    }
    #keranjangCard.card-masuk  { opacity: 1;  transform: scale(1)    translateY(0); }
    #keranjangCard.card-keluar { opacity: 0;  transform: scale(0.95) translateY(8px); }

    @media (prefers-reduced-motion: reduce) {
        #keranjangModal, #keranjangCard { transition: none; }
    }
</style>

<div id="keranjangModal" role="dialog" aria-modal="true" aria-labelledby="keranjangJudul"
     class="modal-keluar fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4"
     style="pointer-events:none;">
    <div id="keranjangCard" class="card-keluar bg-white rounded-2xl p-6 max-w-sm w-full text-center shadow-xl">
        <span id="keranjangIkon" class="w-14 h-14 mx-auto rounded-full bg-green-50 text-green-600 flex items-center justify-center mb-4">
            <i id="keranjangIkonI" class="fa-solid fa-check text-xl" aria-hidden="true"></i>
        </span>
        <h2 id="keranjangJudul" class="text-xl font-extrabold text-primary mb-2">Ditambahkan ke keranjang</h2>
        <p id="keranjangPesan" class="text-sm text-gray-600 mb-6"></p>
        <div class="flex flex-col gap-2">
            <a id="keranjangLihat" href="keranjang.php"
               class="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-secondary focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-secondary transition">Lihat keranjang</a>
            <button id="keranjangTutup" type="button"
                    class="w-full bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition">Lanjut belanja</button>
        </div>
    </div>
</div>

<script>
    (function () {
        var modal    = document.getElementById('keranjangModal');
        var card     = document.getElementById('keranjangCard');
        if (!modal || !window.fetch) return;

        var elJudul  = document.getElementById('keranjangJudul');
        var elPesan  = document.getElementById('keranjangPesan');
        var elIkon   = document.getElementById('keranjangIkon');
        var elIkonI  = document.getElementById('keranjangIkonI');
        var elLihat  = document.getElementById('keranjangLihat');
        var btnTutup = document.getElementById('keranjangTutup');
        var pemicu   = null;
        var tutupTimer = null;

        function tampil(ok, judul, pesan, tombolLihat) {
            if (tutupTimer) clearTimeout(tutupTimer);

            elJudul.textContent = judul;
            elPesan.textContent = pesan;
            elIkon.className = 'w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-4 ' +
                (ok ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600');
            elIkonI.className = 'fa-solid text-xl ' + (ok ? 'fa-check' : 'fa-xmark');
            elLihat.classList.toggle('hidden', !tombolLihat);

            // Pastikan modal terlihat, lalu trigger transisi masuk
            modal.style.pointerEvents = 'auto';
            modal.classList.remove('modal-keluar');
            card.classList.remove('card-keluar');
            // rAF ganda agar browser sempat merender state awal sebelum transisi
            requestAnimationFrame(function () {
                requestAnimationFrame(function () {
                    modal.classList.add('modal-masuk');
                    card.classList.add('card-masuk');
                });
            });

            btnTutup.focus();
        }

        function tutup() {
            modal.classList.remove('modal-masuk');
            card.classList.remove('card-masuk');
            modal.classList.add('modal-keluar');
            card.classList.add('card-keluar');
            modal.style.pointerEvents = 'none';
            if (pemicu) pemicu.focus();
        }

        function perbaruiBadge(jumlah) {
            document.querySelectorAll('[data-badge-keranjang]').forEach(function (el) {
                el.textContent = jumlah;
                el.classList.toggle('hidden', jumlah <= 0);
            });
        }

        btnTutup.addEventListener('click', tutup);
        modal.addEventListener('click', function (ev) { if (ev.target === modal) tutup(); });
        document.addEventListener('keydown', function (ev) {
            if (ev.key === 'Escape' && modal.classList.contains('modal-masuk')) tutup();
        });

        document.querySelectorAll('form[action$="actionkeranjang.php"]').forEach(function (form) {
            form.addEventListener('submit', function (ev) {
                var tombol = form.querySelector('button[type="submit"]');
                ev.preventDefault();

                var data = new FormData(form);
                data.append('tambah_keranjang', '1');
                pemicu = tombol;
                if (tombol) tombol.disabled = true;

                fetch(form.action, {
                    method: 'POST',
                    body: data,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    credentials: 'same-origin'
                })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d.ok) {
                        perbaruiBadge(d.jumlah);
                        var pesan = d.nama + ' sudah masuk keranjang. Total ' + d.jumlah + ' barang.';
                        if (d.dibatasi) pesan += ' Jumlah disesuaikan dengan stok (' + d.stok + ').';
                        tampil(true, 'Ditambahkan ke keranjang', pesan, true);
                    } else {
                        tampil(false, 'Belum bisa ditambahkan', d.pesan || 'Terjadi kesalahan. Coba lagi.', false);
                    }
                })
                .catch(function () {
                    // Jaringan gagal: kirim form biasa sebagai cadangan
                    var h = document.createElement('input');
                    h.type = 'hidden'; h.name = 'tambah_keranjang'; h.value = '1';
                    form.appendChild(h);
                    form.submit();
                })
                .finally(function () { if (tombol) tombol.disabled = false; });
            });
        });
    })();
</script>
